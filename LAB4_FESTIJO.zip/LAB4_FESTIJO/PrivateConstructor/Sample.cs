﻿

namespace PrivateConstructor
{
    class Sample
    {
        public string firstname, lastname;
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
        private Sample()
        {
            System.Console.WriteLine("Private Constructor with no parameter");
        }
    }
}
