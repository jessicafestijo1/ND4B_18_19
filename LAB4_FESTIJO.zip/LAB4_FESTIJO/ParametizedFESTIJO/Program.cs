﻿using System;

namespace ParametizedFESTIJO
{
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Jessica", "Festijo");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
